﻿namespace NotificationService.Core.Enums
{
    public enum NotificationStatus
    {
        Pending,
        Sent,
        Failed,
    }
}
