﻿namespace NotificationService.Core.Enums
{
    public enum NotificationType
    {
        Email,
        Sms,
        Push,
    }
}
