﻿using BookingService.Core.Entities;

namespace BookingService.DataAccess.Persistence.Interfaces
{
    public interface ISeatRepository : IRepository<Seat>
    {
    }
}
