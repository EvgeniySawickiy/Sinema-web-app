﻿namespace BookingService.Core.Enums
{
    public enum PaymentStatus
    {
        Pending,
        Paid,
        Failed,
    }
}
