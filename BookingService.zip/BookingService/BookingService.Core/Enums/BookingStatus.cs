﻿namespace BookingService.Core.Enums
{
    public enum BookingStatus
    {
        Pending,
        Confirmed,
        Canceled,
    }
}
