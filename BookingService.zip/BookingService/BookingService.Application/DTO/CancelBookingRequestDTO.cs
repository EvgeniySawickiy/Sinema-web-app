﻿namespace BookingService.Application.DTO
{
    public class CancelBookingRequestDTO
    {
        public string Reason { get; set; }
    }
}
